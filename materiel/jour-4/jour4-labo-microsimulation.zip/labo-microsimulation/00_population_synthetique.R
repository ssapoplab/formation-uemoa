# =============================================================================
# 00_population_synthetique.R
# Recrée la population synthétique de Djibo du labo du mercredi (Fabrice Yaméogo) :
# calage IPU de l'échantillon EHCVM (région du Sahel) sur les marges du RGPH 2019,
# puis tirage des poids entiers (TRS) et réplication des ménages.
# Résultat : donnees/pop_djibo_synthetique.csv (une ligne par individu synthétique).
#
# Ce script est facultatif : le fichier est déjà fourni dans donnees/.
# Il demande le paquet mlfit, installé mercredi.
# =============================================================================
library(mlfit)
library(tidyverse)

ind    <- read_csv("donnees/individus_sahel.csv", show_col_types = FALSE)
men    <- read_csv("donnees/menages_sahel.csv",   show_col_types = FALSE)
marges <- read_csv("donnees/marges_djibo.csv",    show_col_types = FALSE)

N_men <- 16159   # ménages de Djibo (RGPH 2019)

controle <- function(nom_variable) {
  marges %>%
    filter(variable == nom_variable) %>%
    select(modalite, N) %>%
    rename(!!nom_variable := modalite) %>%
    as.data.frame()
}

ech <- ind %>% left_join(men, by = "hhid") %>% as.data.frame()

probleme <- ml_problem(
  ref_sample  = ech,
  field_names = special_field_names(groupId = "hhid", individualId = "id_ind",
                                    count = "N", prior_weight = "poids"),
  group_controls      = list(controle("tv"), controle("electricite")),
  individual_controls = list(controle("sexe"), controle("groupe_age"), controle("alpha"))
)
calage <- ml_fit(probleme, algorithm = "ipu", tol = 1e-6)
stopifnot(calage$success)

ech$w_ipu <- calage$weights
men <- men %>% left_join(ech %>% distinct(hhid, w_ipu), by = "hhid")

# poids entiers (TRS) : troncature, puis tirage des ménages complétés
trs <- function(poids) {
  entier <- floor(poids)
  reste  <- poids - entier
  manque <- round(sum(poids)) - sum(entier)
  tires  <- sample(length(poids), size = manque, prob = reste)
  entier[tires] <- entier[tires] + 1
  entier
}
set.seed(2026)
men$w_entier <- trs(men$w_ipu)

pop_men <- men %>%
  uncount(w_entier) %>%
  mutate(id_menage = row_number()) %>%
  select(id_menage, hhid, milieu)

pop_ind <- pop_men %>%
  inner_join(ind %>% select(hhid, numind, lien, sexe, age, instruction), by = "hhid",
             relationship = "many-to-many") %>%
  arrange(id_menage, numind) %>%
  mutate(id = row_number()) %>%
  select(id, id_menage, numind, lien, milieu, sexe, age, instruction)

write_csv(pop_ind, "donnees/pop_djibo_synthetique.csv")
cat("Population synthétique :", nrow(pop_ind), "individus dans", nrow(pop_men), "ménages\n")
