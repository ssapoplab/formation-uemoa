# Labo du jeudi — Microsimulation

1. Décompresser le dossier et ouvrir `jour4-labo-microsimulation.Rmd` dans RStudio.
2. Définir le dossier du fichier comme répertoire de travail (Session > Set Working Directory > To Source File Location).
3. Exécuter les blocs un à un. Seul le paquet `tidyverse` est nécessaire.

`jour4-labo-microsimulation.html` montre le labo déjà exécuté, avec tous les résultats.

Le fichier `donnees/pop_djibo_synthetique.csv` est la population synthétique du mercredi.
Le script `00_population_synthetique.R` (facultatif, paquet `mlfit`) la recrée à partir de l'EHCVM et des marges du RGPH 2019.
